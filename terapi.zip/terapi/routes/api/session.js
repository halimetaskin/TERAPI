import express from 'express';
import { Session } from '../../models/session.js';
import { auth } from '../../middleware/auth.js';

export const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Session
 *   description: Session management
 * components:
 *   schemas:
 *     Session:
 *       type: object
 *       required:
 *         - title
 *         - description
 *         - date
 *       properties:
 *         title:
 *           type: string
 *           description: The title of the session
 *         description:
 *           type: string
 *           description: The description of the session
 */

/**
 * @swagger
 * /session:
 *   get:
 *     summary: Retrieve a list of sessions
 *     description: Retrieve a list of sessions with populated therapist information.
 *     tags: [Session]
 *     responses:
 *       200:
 *         description: A list of sessions.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Session'
 */
router.get('/', async (req, res) => {
    try {
        const session = await Session.find()
            .populate('therapist', 'name _id');
        res.json(session);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

/**
 * @swagger
 * /session/{id}:
 *   get:
 *     summary: Retrieve a session by ID
 *     description: Retrieve a session by ID with populated therapist information.
 *     tags: [Session]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: The session ID
 *     responses:
 *       200:
 *         description: A session object.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Session'
 *       404:
 *         description: Session not found.
 */
router.get('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const session = await Session.findById(id)
            .populate('therapist', '_id name');
        if (!session) {
            return res.status(404).json({ msg: 'Session not found' });
        }
        return res.json(session);
    } catch (e) {
        console.error(e.message);
        res.status(500).send('Server error');
    }
});

/**
 * @swagger
 * /session:
 *   post:
 *     summary: Create a new session
 *     description: Create a new session by a therapist.
 *     tags: [Session]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Session'
 *     security:
 *       - ApiKeyAuth: []
 *     responses:
 *       200:
 *         description: Session created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Session'
 */
router.post('/', auth(['therapist']), async (req, res) => {
    const { title, description } = req.body;

    const randomDateWithinTwoWeeks = () => {
        const today = new Date();
        const twoWeeksLater = new Date(today);
        twoWeeksLater.setDate(today.getDate() + 14);

        return new Date(today.getTime() + Math.random() * (twoWeeksLater.getTime() - today.getTime()));
    };

    try {
        const session = new Session({
            therapist: req.user.id,
            title,
            description,
            date: randomDateWithinTwoWeeks(),
        });

        await session.save();
        res.json({
            id: session.id,
            msg: 'Session created',
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

/**
 * @swagger
 * /session/{id}/register:
 *   post:
 *     summary: Register a user for a session
 *     description: Register a user for a session.
 *     tags: [Session]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: The session ID
 *     security:
 *       - ApiKeyAuth: []
 *     responses:
 *       200:
 *         description: User registered successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Session'
 *       404:
 *         description: Session not found.
 *       400:
 *         description: User already registered or invalid session ID.
 */
router.post('/:id/register', auth(['user']), async (req, res) => {
    const { id } = req.params;
    const userId = req.user.id;

    if (!id) {
        return res.status(400).json({ msg: 'Session ID is required' });
    }

    try {
        const session = await Session.findById(id);

        if (!session) {
            return res.status(404).json({ msg: 'Session not found' });
        }

        if (session.participants.includes(userId)) {
            return res.status(400).json({ msg: 'Already registered for this session' });
        }

        session.participants = [...session.participants, userId];
        await session.save();

        res.json(session);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

/**
 * @swagger
 * /session/{id}:
 *   put:
 *     summary: Update a session
 *     description: Update a session by a therapist.
 *     tags: [Session]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: The session ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Session'
 *     security:
 *       - ApiKeyAuth: []
 *     responses:
 *       200:
 *         description: Session updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Session'
 *       404:
 *         description: Session not found.
 *       401:
 *         description: Not authorized.
 */
router.put('/:id', auth(['therapist']), async (req, res) => {
    const { title, description } = req.body;

    try {
        let session = await Session.findById(req.params.id);

        if (!session) {
            return res.status(404).json({ msg: 'Session not found' });
        }

        if (session.therapist.toString() !== req.user.id) {
            return res.status(403).json({ msg: 'Not authorized' });
        }

        session = await Session.findByIdAndUpdate(req.params.id, { title, description }, { new: true });

        res.json(session);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

/**
 * @swagger
 * /session/{id}:
 *   delete:
 *     summary: Delete a session
 *     description: Delete a session by a therapist.
 *     tags: [Session]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: The session ID
 *     security:
 *       - ApiKeyAuth: []
 *     responses:
 *       200:
 *         description: Session removed successfully.
 *       404:
 *         description: Session not found.
 *       401:
 *         description: Not authorized.
 */
router.delete('/:id', auth(['therapist']), async (req, res) => {
    try {
        const session = await Session.findById(req.params.id);

        if (!session) {
            return res.status(404).json({ msg: 'Session not found' });
        }

        if (session.therapist.toString() !== req.user.id) {
            return res.status(401).json({ msg: 'Not authorized' });
        }

        await Session.deleteOne({ _id: req.params.id });

        res.json({ msg: 'Session removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});
