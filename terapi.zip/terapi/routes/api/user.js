import express from 'express';
import {User} from '../../models/user.js';
import {auth} from '../../middleware/auth.js';
import bcrypt from 'bcryptjs';
import {config} from "../../config/config.js";
import jwt from "jsonwebtoken";

export const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: User
 *   description: User management
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     User:
 *       type: object
 *       required:
 *         - name
 *         - email
 *         - password
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated id of the user
 *         name:
 *           type: string
 *           description: The name of the user
 *         email:
 *           type: string
 *           description: The email of the user
 *         password:
 *           type: string
 *           description: The password of the user
 *         role:
 *           type: string
 *           enum: [therapist, user]
 *           description: The role of the user
 *     ApiResponse:
 *       type: object
 *       properties:
 *         msg:
 *           type: string
 */

/**
 * @swagger
 * /user:
 *   get:
 *     summary: Get current user
 *     description: Get the details of the currently authenticated user.
 *     tags: [User]
 *     security:
 *       - ApiKeyAuth: []
 *     responses:
 *       200:
 *         description: Current user details.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 */
router.get('/', auth(), async (req, res) => {
    try {
        const user = await User.findById(req.user.id).select('-password');
        res.json(user);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

/**
 * @swagger
 * /user/therapists:
 *   get:
 *     summary: Get all therapists
 *     description: Get a list of all therapists.
 *     tags: [User]
 *     responses:
 *       200:
 *         description: A list of therapists.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/User'
 */
router.get('/therapists', (req, res) => {
    User.find().where({role: 'therapist'}).select('_id name role')
        .then(user => {
            res.json(user)
        })
        .catch(console.error);
});

/**
 * @swagger
 * /user/update:
 *   put:
 *     summary: Update user profile
 *     description: Update the profile details of the currently authenticated user.
 *     tags: [User]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *     security:
 *       - ApiKeyAuth: []
 *     responses:
 *       200:
 *         description: User profile updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 */
router.put('/update', auth(), async (req, res) => {
    const {name, email} = req.body;

    try {
        const user = await User.findById(req.user.id);

        if (!user) {
            return res.status(404).json({msg: 'User not found'});
        }

        // Alanları güncelle
        if (name) user.name = name;
        if (email) user.email = email;

        await user.save();

        res.json({msg: 'User updated successfully', user});
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

/**
 * @swagger
 * /user/update-password:
 *   put:
 *     summary: Update user password
 *     description: Update the password of the currently authenticated user.
 *     tags: [User]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               password:
 *                 type: string
 *     security:
 *       - ApiKeyAuth: []
 *     responses:
 *       200:
 *         description: Password updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 msg:
 *                   type: string
 */
router.put('/update-password', auth(), async (req, res) => {
    const {password} = req.body;

    try {
        const user = await User.findById(req.user.id);

        if (!user) {
            return res.status(404).json({msg: 'User not found'});
        }

        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(password, salt);

        await user.save();

        res.json({msg: 'Password updated successfully'});
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});
