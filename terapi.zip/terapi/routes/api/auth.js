import express from 'express';

import {User} from '../../models/user.js';
import {createHash} from "node:crypto";

export const router = express.Router();

/**
 * @swagger
 * tags:
 *  name: Auth
 * components:
 *   schemas:
 *     User:
 *       type: object
 *       required:
 *         - name
 *         - email
 *         - password
 *       properties:
 *         name:
 *           type: string
 *           description: The name of the user
 *         email:
 *           type: string
 *           description: The email of the user
 *         password:
 *           type: string
 *           description: The password of the user
 *         role:
 *           type: string
 *           enum: [therapist, user]
 *           description: The role of the user
 */

/**
 * @swagger
 * /auth/register:
 *   post:
 *     summary: Register a new user
 *     description: Register a new user (therapist or regular user).
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/User'
 *     responses:
 *       200:
 *         description: User registered successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 token:
 *                   type: string
 *                 refreshToken:
 *                   type: string
 */
router.post('/register', async (req, res) => {
    const {name, email, password, role} = req.body;

    try {
        let user = await User.findOne({email});
        if (user) {
            return res.status(400).json({msg: 'User already exists'});
        }

        user = new User({
            name,
            email,
            password,
            role: role || 'user',
        });

        await user.save();

        const token = user.getSignedJwtToken();
        const refreshToken = user.getRefreshToken();
        res.cookie('token', token, {httpOnly: true});

        res.json({token, refreshToken});
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Login a user
 *     description: Login a user and return a JWT token.
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *
 *     responses:
 *       200:
 *         description: User logged in successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 token:
 *                   type: string
 *                 refreshToken:
 *                   type: string
 */
router.post('/login', async (req, res) => {
    const {email, password} = req.body;

    try {
        let user = await User.findOne({email});
        if (!user) {
            return res.status(400).json({msg: 'Invalid credentials user'});
        }

        const isMatch = await user.matchPassword(password);
        if (!isMatch) {
            return res.status(400).json({msg: 'Invalid credentials şifre'});
        }

        const token = user.getSignedJwtToken();
        const refreshToken = user.getRefreshToken();
        await user.save();

        res.cookie('token', token, {httpOnly: true});
        res.json({token, refreshToken});
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

/**
 * @swagger
 * /auth/token:
 *   post:
 *     summary: Refresh access token
 *     description: Refreshes the access token using a valid refresh token.
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               refreshToken:
 *                 type: string
 *     responses:
 *       200:
 *         description: Access token refreshed successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 token:
 *                   type: string
 *                 refreshToken:
 *                   type: string
 *       400:
 *         description: Invalid refresh token.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 msg:
 *                   type: string
 *       500:
 *         description: Server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 msg:
 *                   type: string
 */
router.post('/token', async (req, res) => {
    const {refreshToken} = req.body;

    if (!refreshToken) {
        return res.status(400).json({msg: 'Refresh token is required'});
    }

    try {
        const hashedToken = createHash('sha256').update(refreshToken).digest('hex');
        const user = await User.findOne({refreshToken: hashedToken});

        if (!user) {
            return res.status(400).json({msg: 'Invalid refresh token'});
        }

        const token = user.getSignedJwtToken();
        const newRefreshToken = user.getRefreshToken();
        await user.save();

        res.json({token, refreshToken: newRefreshToken});
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});