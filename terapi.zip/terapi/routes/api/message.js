import express from 'express';
import {Message} from '../../models/message.js';
import {User} from '../../models/user.js';
import {auth} from "../../middleware/auth.js";

export const router = express.Router();


// Mesaj gönderme
router.post('/', auth(), async (req, res) => {
    const {receiverId, content} = req.body;

    try {
        const receiver = await User.findOne({_id: receiverId});

        if (!receiver) {
            return res.status(404).json({msg: 'Receiver not found'});
        }
        if (receiverId === req.user.id.toString()) {
            return res.status(400).json({ msg: "You can't send a message to yourself" });
        }

        const message = new Message({
            sender: req.user.id,
            receiver: receiverId,
            content,
        });

        await message.save();
        res.json(message);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

// Mesajları listeleme
router.get('/conversations/:userId', auth(), async (req, res) => {
    const userId = req.params.userId;

    try {
        const messages = await Message.find({
            $or: [
                {sender: req.user.id, receiver: userId},
                {sender: userId, receiver: req.user.id}
            ]
        }).sort({createdAt: -1});

        res.json(messages);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});


// Mesaj güncelleme
router.put('/:id', auth(), async (req, res) => {
    const { content } = req.body;
    const messageId = req.params.id;

    try {
        let message = await Message.findById(messageId);

        if (!message) {
            return res.status(404).json({ msg: 'Message not found' });
        }

        // Mesajın sahibinin kullanıcı olup olmadığını kontrol et
        if (message.sender.toString() !== req.user.id) {
            return res.status(401).json({ msg: 'Not authorized' });
        }

        message.content = content;
        await message.save();

        res.json(message);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

// Mesaj silme
router.delete('/:id', auth(), async (req, res) => {
    const messageId = req.params.id;

    try {
        const message = await Message.findById(messageId);

        if (!message) {
            return res.status(404).json({ msg: 'Message not found' });
        }

        // Mesajın sahibinin kullanıcı olup olmadığını kontrol et
        if (message.sender.toString() !== req.user.id) {
            return res.status(401).json({ msg: 'Not authorized' });
        }

        await Message.findByIdAndDelete(messageId);

        res.json({ msg: 'Message removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});