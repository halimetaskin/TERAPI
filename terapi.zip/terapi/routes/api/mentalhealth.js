import express from 'express';
import Parser from 'rss-parser';

const router = express.Router();
const parser = new Parser();

router.get("/", async (req, res) => {
    try {
        const feed = await parser.parseURL('https://mhaustralia.org/news/feed');
        const items = feed.items.map(item => ({
            title: item.title,
            link: item.link,
            pubDate: item.pubDate,
            contentSnippet: item.contentSnippet,
            content: item.content,
            guid: item.guid,
        }));
        res.json(items);
    } catch (error) {
        console.error('Error fetching RSS feed:', error);
        res.status(400).send("Error fetching Mental Health API");
    }
});

export default router;