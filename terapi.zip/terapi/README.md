# Terapi Ödev
Frontendi ne yazık ki yetiştiremedim ancak diğer tüm özellikleri mevcut. Testleri yazdım docker ile mongodb kullandım. Swagger ile kolayca api istekleri yapılabiliyor authenticate edilmiş bir şekilde. 

Kurulum
```
npm i -g pnpm
pnpm i
docker-compose up -d 
```

Eğer docker yüklü değilse https://www.docker.com/ bu adresten bilgisayarınıza indirebilirsiniz. 

testleri denemeden önce .env dosyasındaki `NODE_ENV=dev` test olarak değiştirdikten sonra `pnpm test` yazarak test edebilirsiniz. 