import request from 'supertest';
import mongoose from 'mongoose';
import {app} from '../server.js';
import { User } from '../models/User.js';
import {afterAll, beforeAll, describe, expect, it} from "@jest/globals";

const email = "testuser@example.com"
describe('Users API', () => {
    let token;
    let userId;

    beforeAll(async () => {
        // MongoDB'ye bağlan
        await mongoose.connect('mongodb://localhost:27017/therapyapp_test', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
    });

    afterAll(async () => {
        // Test veritabanını temizle
        await User.deleteMany({});
        await mongoose.connection.close();

    });

    it('should register a user', async () => {
        const res = await request(app)
            .post('/auth/register')
            .send({
                name: 'Test User',
                email,
                password: 'password123',
            });

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('token');
        expect(res.body).toHaveProperty('refreshToken');

        // Token ve kullanıcı bilgilerini sakla
        token = res.body.token;
        userId = (await User.findOne({email})).id;
    });

    it('should login a user', async () => {
        const res = await request(app)
            .post('/auth/login')
            .send({
                email,
                password: 'password123',
            });

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('token');
        expect(res.body).toHaveProperty('refreshToken');

        // Token'ı güncelle
        token = res.body.token;
    });
    it('should update user profile', async () => {
        const res = await request(app)
            .put('/user/update')
            .set('x-auth-token', token)
            .send({
                name: 'Updated Test User',
                email: 'updatedtestuser@example.com',
            });

        expect(res.statusCode).toEqual(200);
        expect(res.body.user).toHaveProperty('name', 'Updated Test User');
        expect(res.body.user).toHaveProperty('email', 'updatedtestuser@example.com');
    });

});