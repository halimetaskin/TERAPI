import request from 'supertest';
import mongoose from 'mongoose';
import {app} from '../server.js';
import {User} from '../models/User';
import {Message} from '../models/Message';
import {afterAll, beforeAll, describe, expect, it} from "@jest/globals";

describe('Messages API', () => {
    let token;
    let userId;
    let receiverId;
    let messageId;

    beforeAll(async () => {
        await mongoose.connect('mongodb://localhost:27017/therapyapp_test', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });

        const user = new User({
            name: 'Test User Message',
            email: 'testusermessage@example.com',
            password: 'password123',
            role: 'user',
        });
        await user.save();

        userId = user._id;

        token = user.getSignedJwtToken();

        const receiver = new User({
            name: 'Receiver User',
            email: 'receivermessage@example.com',
            password: 'password123',
            role: 'user',
        });
        await receiver.save();

        receiverId = receiver._id;
    });

    afterAll(async () => {
        await User.deleteMany({});
        await Message.deleteMany({});
        await mongoose.connection.close();
    });

    it('should send a message', async () => {
        const res = await request(app)
            .post('/message')
            .set('x-auth-token', token)
            .send({
                receiverId: receiverId.toString(),
                content: 'Hello, this is a test message.',
            });

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('_id');
        expect(res.body).toHaveProperty('sender', userId.toString());
        expect(res.body).toHaveProperty('receiver', receiverId.toString());
        expect(res.body).toHaveProperty('content', 'Hello, this is a test message.');

        messageId = res.body._id;
    });

    it('should not allow sending a message to oneself', async () => {
        const res = await request(app)
            .post('/message')
            .set('x-auth-token', token)
            .send({
                receiverId: userId.toString(),
                content: 'Hello, this is a test message.',
            });

        expect(res.statusCode).toEqual(400);
        expect(res.body).toHaveProperty('msg', "You can't send a message to yourself");
    });

    it('should get all messages in a conversation', async () => {
        const message = new Message({
            sender: userId,
            receiver: receiverId,
            content: 'This is a message in the conversation.',
        });
        await message.save();

        const res = await request(app)
            .get(`/message/conversations/${receiverId.toString()}`)
            .set('x-auth-token', token);

        expect(res.statusCode).toEqual(200);
        expect(res.body.length).toBeGreaterThan(0);
        expect(res.body[0]).toHaveProperty('content', 'This is a message in the conversation.');
    });

    it('should update a message', async () => {
        const newContent = 'This is the updated content';

        const res = await request(app)
            .put(`/message/${messageId}`)
            .set('x-auth-token', token)
            .send({content: newContent});

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('content', newContent);
    });

    it('should delete a message', async () => {
        const res = await request(app)
            .delete(`/message/${messageId}`)
            .set('x-auth-token', token);

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('msg', 'Message removed');

        const message = await Message.findById(messageId);
        expect(message).toBeNull();
    });
});