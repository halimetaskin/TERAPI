import request from 'supertest';
import mongoose from 'mongoose';
import {app} from '../server.js';
import {User} from '../models/User.js';
import {Session} from '../models/Session.js';
import {afterAll, beforeAll, describe, expect, it} from '@jest/globals';
import jwt from "jsonwebtoken";
import {config} from "../config/config.js";

const password = 'password123';

describe('Sessions API', () => {
    let therapistToken;
    let userToken;
    let therapistId;
    let userId;
    let sessionId;

    beforeAll(async () => {
        // MongoDB'ye bağlan
        await mongoose.connect('mongodb://localhost:27017/therapyapp_test', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
    });

    afterAll(async () => {
        // Test veritabanını temizle
        await User.deleteMany({});
        await Session.deleteMany({});
        await mongoose.connection.close();
    });

    it('should register a therapist', async () => {
        const res = await request(app)
            .post('/auth/register')
            .send({
                name: 'New Therapist',
                email: 'newtherapist@example.com',
                password,
                role: 'therapist',
            });

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('token');
        expect(res.body).toHaveProperty('refreshToken');

        const token = jwt.verify(res.body.token, config.jwtSecret)
        therapistId = token.id
        therapistToken = res.body.token
    });

    it('should register a user', async () => {
        const res = await request(app)
            .post('/auth/register')
            .send({
                name: 'New User',
                email: 'newuser@example.com',
                password,
                role: 'user',
            });

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('token');
        expect(res.body).toHaveProperty('refreshToken');


        const token = jwt.verify(res.body.token, config.jwtSecret)
        userId = token.id
        userToken = res.body.token
    });

    it('should create a session as therapist', async () => {
        const res = await request(app)
            .post('/session')
            .set('x-auth-token', therapistToken)
            .send({
                title: 'Test Session',
                description: 'This is a test session',
            });

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('id');
        expect(res.body).toHaveProperty('msg', 'Session created');
        console.log(res.body)
        sessionId = res.body.id;
    });

    it('should allow user to join a session', async () => {
        const res = await request(app)
            .post(`/session/${sessionId}/register`)
            .set('x-auth-token', userToken)


        expect(res.statusCode).toEqual(200);
        expect(res.body.participants).toContainEqual(userId.toString());
    });

    it('should get all sessions for therapist', async () => {
        const res = await request(app)
            .get('/session')

        expect(res.statusCode).toEqual(200);
        expect(res.body.length).toBeGreaterThan(0);
    });

    it('should update a session as therapist', async () => {
        const res = await request(app)
            .put(`/session/${sessionId}`)
            .set('x-auth-token', therapistToken)
            .send({
                title: 'Updated Test Session',
                description: 'This is an updated test session',
            });

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('_id', sessionId);
        expect(res.body).toHaveProperty('title', 'Updated Test Session');
        expect(res.body).toHaveProperty('description', 'This is an updated test session');
    });

    it('should delete a session as therapist', async () => {
        const res = await request(app)
            .delete(`/session/${sessionId}`)
            .set('x-auth-token', therapistToken);

        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('msg', 'Session removed');
    });
});