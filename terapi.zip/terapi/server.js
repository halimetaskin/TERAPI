import express from "express";
import mongoose from "mongoose";
import { router as authRouter } from "./routes/api/auth.js";
import { router as sessionRouter } from "./routes/api/session.js";
import { router as messageRouter } from "./routes/api/message.js";
import { router as userRouter } from "./routes/api/user.js";
import { config as dotEnvConf } from "dotenv";
import { Server } from "socket.io";
import { Message } from "./models/message.js";
import * as http from "node:http";
import { router as swaggerRouter } from "./swagger.js";
import jwt from "jsonwebtoken";
import { config } from "./config/config.js";
import { redirectIfAuthenticated, setUser } from "./middleware/auth.js";
import cookieParser from 'cookie-parser';
import mentalhealthRouter from "./routes/api/mentalhealth.js";
import cors from "cors"
dotEnvConf();

export const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});
app.use(cors())
app.use(express.json());

app.use(setUser);

app.use(swaggerRouter);
app.use(cookieParser());

app.use(setUser);  // Middleware'in doğru sırayla kullanıldığından emin olun

app.use("/auth", authRouter);
app.use("/session", sessionRouter);
app.use("/message", messageRouter);
app.use("/user", userRouter);
app.use("/mentalHealth",mentalhealthRouter)

app.get("/", (req, res) => {
    res.render("index", { user: res.locals.user });
});

app.get("/login", redirectIfAuthenticated, (req, res) => {
    res.render("login");
});

app.get("/register", redirectIfAuthenticated, (req, res) => {
    res.render("register");
});

const mongoURI = process.env.NODE_ENV === 'test' ? 'mongodb://localhost:27017/therapyapp_test' : 'mongodb://localhost:27017/therapyapp';
mongoose.connect(mongoURI)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));

// Socket.IO bağlantısı
io.use((socket, next) => {
    if (socket.handshake.query && socket.handshake.query.token) {
        jwt.verify(socket.handshake.query.token, config.jwtSecret, (err, decoded) => {
            if (err) return next(new Error('Authentication error'));
            socket.user = decoded;
            next();
        });
    } else {
        next(new Error('Authentication error'));
    }
}).on('connection', (socket) => {
    console.log('a user connected:', socket.user.id);

    socket.on('sendMessage', async (data) => {
        const { receiverId, content } = data;
        const message = new Message({
            sender: socket.user.id,
            receiver: receiverId,
            content,
        });

        await message.save();

        io.to(receiverId).emit('receiveMessage', message);
        io.to(socket.user.id).emit('receiveMessage', message);
    });

    socket.on('disconnect', () => {
        console.log('user disconnected:', socket.user.id);
    });
});

const PORT = process.env.PORT || 3000;
if (process.env.NODE_ENV !== 'test') {
    server.listen(PORT, () => console.log(`Server started on port ${PORT}`));
}