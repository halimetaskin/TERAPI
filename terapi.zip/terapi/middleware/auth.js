// auth middleware

import {config} from "../config/config.js";
import jwt from "jsonwebtoken";

export const auth = (roles = []) => {
    return (req, res, next) => {
        const token = req.header('x-auth-token');

        if (!token) {
            return res.status(401).json({msg: 'No token, authorization denied'});
        }

        try {
            const decoded = jwt.verify(token, config.jwtSecret);
            req.user = decoded;

            if (roles.length && !roles.includes(req.user.role)) {
                return res.status(403).json({msg: 'Access denied'});
            }

            next();
        } catch (err) {
            res.status(401).json({msg: 'Token is not valid'});
        }
    };
};

export function redirectIfAuthenticated(req, res, next) {
    const token = req.cookies ? req.cookies.token : null;
    if (token) {
        jwt.verify(token, config.jwtSecret, (err) => {
            if (!err) {
                return res.redirect('/');
            }
        });
    }
    next();
}

export function ensureAuthenticated(req, res, next) {
    const token = req.cookies ? req.cookies.token : null; // JWT token'ını çerezden al
    if (!token) {
        return res.redirect('/login');
    }

    jwt.verify(token, config.jwtSecret, (err, decoded) => {
        if (err) {
            return res.redirect('/login');
        }
        req.user = decoded.user;
        res.locals.user = req.user;
        next();
    });
}

export function setUser(req, res, next) {
    const token = req.cookies ? req.cookies.token : null;
    if (token) {
        jwt.verify(token, config.jwtSecret, (err, decoded) => {
            if (!err) {
                res.locals.user = decoded.user;
            } else {
                res.locals.user = null;
            }
            next();
        });
    } else {
        res.locals.user = null;
        next();
    }
}