import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import express from 'express';

export const router = express.Router();

const options = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'API Documentation',
            version: '1.0.0',
            description: 'A simple Express Library API',
        },
        servers: [
            {
                url: 'http://localhost:3000', // Değiştirin
            },
        ],
        components: {
            securitySchemes: {
                ApiKeyAuth: {
                    type: 'apiKey',
                    in: 'header',
                    name: 'x-auth-token',
                },
            },
        },
        security: [
            {
                ApiKeyAuth: [],
            },
        ],
    },
    apis: ['./routes/api/*.js'], // API tanımları olan dosyalar
};

const specs = swaggerJsdoc(options);
const swaggerUiOptions = {
    explorer: true,
    swaggerOptions: {
        docExpansion: 'none', // Tüm nesneleri varsayılan olarak kapalı yapar
        displayRequestDuration: true,
    },
};
router.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs, swaggerUiOptions));
