import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import {config} from "../config/config.js";
import {createHash, randomBytes} from "node:crypto";
import jwt from "jsonwebtoken";

const {Schema} = mongoose;

// Kullanıcı şeması oluşturma
const userSchema = new Schema({
    name: {
        type: String,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    role: {
        type: String,
        enum: ['therapist', 'user'],
        default: 'user',
    },
    refreshToken: {
        type: String,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    },
});

// Şifre hashleme
userSchema.pre("save", function (next) {
    if (!this.isModified("password")) return next();

    bcrypt.genSalt(10, (err, salt) => {
        if (err) return next(err);
        bcrypt.hash(this.password, salt, (error, hash) => {
            if (error) return next(error);
            this.password = hash;
            next();
        });
    });
});

// Şifre doğrulama
userSchema.methods.matchPassword = async function (enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

// JWT token oluşturma
userSchema.methods.getSignedJwtToken = function () {
    return jwt.sign({id: this._id, name: this.name, role: this.role}, config.jwtSecret, {
        expiresIn: config.jwtExpire,
    });
};

// Refresh token oluşturma
userSchema.methods.getRefreshToken = function () {
    const refreshToken = randomBytes(20).toString('hex');
    this.refreshToken = createHash('sha256').update(refreshToken).digest('hex');
    return refreshToken;
};

export const User = mongoose.model('User', userSchema);