import mongoose from "mongoose";

const Schema = mongoose.Schema;

const sessionSchema = new Schema({
    therapist: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    title: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    date: {
        type: Date,
        required: true,
    },
    participants: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    },
});

sessionSchema.pre('save', function (next) {
    this.updatedAt = Date.now();
    next();
});

export const Session = mongoose.model('Session', sessionSchema);
