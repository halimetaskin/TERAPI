export const config = {
    expirationDate: 60*5,
    passwordSecret: "secretKey",
    jwtSecret: "secretKey",
    jwtExpire: "5m",
}